# SICE Security Report Generators — User Guide

**Version:** 1.0  
**Date:** 22 July 2026  
**Prepared By:** Head of Security — P DORFLING  
**Organization:** Soft-Ice Catering Equipment (SICE)

---

## Overview

Three professional report generation tools with SICE branding (`#456BAA` blue), footer signature, and dual export formats (PDF + WhatsApp copy-paste).

### What You Get

- **SICE_EOD_REPORT.html** — End-of-Day Security Report generator
- **SICE_MOVEMENT_LOG.html** — Movement Log Report generator  
- **generate_monthly_report.py** — Monthly Security Summary PDF (Python script)

All reports feature:
- ✅ SICE company logo and branding
- ✅ Professional dark theme optimized for mobile/desktop
- ✅ PDF export for archival and formal submission
- ✅ WhatsApp copy-paste format for instant team messaging
- ✅ Signature: **Head of Security — P DORFLING**
- ✅ No callsigns in the actual reports (clean, professional format)

---

## 1. END-OF-DAY SECURITY REPORT (EOD Report)

**File:** `SICE_EOD_REPORT.html`

### What It Does

Generates a structured end-of-day security report covering premises status (gates, alarm, CCTV, incidents).

### How to Use

1. **Open in browser:** Double-click `SICE_EOD_REPORT.html` or drag into any web browser
2. **Fill in details:**
   - Set today's date (auto-fills current date)
   - Set time secured (time when final check was completed)
   - Toggle premises status checkboxes (Gates, Alarm, CCTV, Incidents)
   - Add any additional notes

3. **Export:**
   - **PDF:** Click "📥 Export as PDF" → saves as `SICE_EOD_Report_[DATE].pdf`
   - **WhatsApp:** Click "📋 Copy WhatsApp Format" → text copied to clipboard → paste into WhatsApp

### WhatsApp Format Example

```
🔒 *END OF DAY SECURITY REPORT*
━━━━━━━━━━━━━━━━━━━━
📅 *Date:* Wednesday, 22 July 2026
🕐 *Time Secured:* 14:25
━━━━━━━━━━━━━━━━━━━━
🏭 *Premises Status*
• Gates & Doors: All secure ✅
• Alarm: Yes — Alarm Armed ✅
• CCTV: Yes — CCTV Active ✅
• Incidents: None ✅
━━━━━━━━━━━━━━━━━━━━
✅ *Soft-Ice Catering Equipment premises are secured and safe.*

— Head of Security
  P DORFLING
```

### PDF Output

Professional single-page report with:
- Company header with S logo
- Date and time metadata
- Premises status checklist
- Security summary statement
- Officer signature footer

---

## 2. MOVEMENT LOG REPORT

**File:** `SICE_MOVEMENT_LOG.html`

### What It Does

Documents personnel movement between locations (site visits, school runs, emergency extractions, etc.).

### How to Use

1. **Open in browser:** Double-click `SICE_MOVEMENT_LOG.html`
2. **Fill in movement details:**
   - **Date:** Movement date (auto-fills today)
   - **Purpose:** Work, Emergency, Maintenance, or Personal
   - **Reason:** Why the movement occurred (e.g., "School Run", "Client Visit")
   - **Requested By:** Person who authorized the movement
   - **Accompanying:** Any personnel with the officer
   - **From/To:** Departure and arrival locations
   - **Departure/Arrival Times:** Movement timeline
   - **Status:** Completed, In Progress, or Pending

3. **Export:**
   - **PDF:** Click "📥 Export as PDF" → saves as `SICE_Movement_Log_[DATE].pdf`
   - **WhatsApp:** Click "📋 Copy WhatsApp Format" → instant message format

### WhatsApp Format Example

```
🛡️ *MOVEMENT RECORD*
━━━━━━━━━━━━━━━━━━━━
🏷️ *Purpose:*  💼 Work
📍 *Reason:*   🏫 School Run
👤 *Requested By:* Mrs Palmer
👥 *Accompanying:* Zellie
📅 *Date:* Wednesday, 22 July 2026

🗺️ *ROUTE*
🟢 *From:*  HQ
🔴 *To:*    H1

🕐 *TIMELINE*
┌─────────────────────────
│ 🟢 *Departure:*          13:10
│ 📍 *Arrived at loc:*     13:45
│ 🏠 *Arrived at:*         H1
│ ⏱️ *Duration:*           35m
└─────────────────────────

🚦 *Status:* 🟢 Completed
👤 *Officer:* PHILIP
━━━━━━━━━━━━━━━━━━━━

— Head of Security
  P DORFLING
```

**Note:** Duration is calculated automatically (arrival time − departure time).

### PDF Output

Single-page report with:
- Movement purpose and authorization
- Route (From/To locations)
- Timeline with automatic duration calculation
- Status badge (Completed/In Progress/Pending)
- Officer signature

---

## 3. MONTHLY SECURITY REPORT

**File:** `generate_monthly_report.py`

### What It Does

Generates a comprehensive monthly security summary PDF with metrics, observations, and recommendations.

### How to Use (Command Line)

**Generate current month:**
```bash
python3 generate_monthly_report.py
```

**Generate specific month:**
```bash
python3 generate_monthly_report.py 7 2026
# Generates July 2026 report
```

**Output:** `SICE_Monthly_Report_2026_07.pdf` (in current directory)

### How to Customize

Edit the `sample_data` dictionary in the Python script to include your actual data:

```python
sample_data = {
    'total_incidents': 0,           # Number of incidents this month
    'security_alerts': 5,           # Number of security alerts
    'gate_checks': 156,             # Gate access checks performed
    'cctv_issues': 0,              # CCTV system issues
    'alarm_tests': 4,              # Alarm system tests performed
    'patrol_hours': 480,           # Total patrol hours
    'personnel_trained': 8,        # Number of personnel trained
    'areas_covered': ['Sinoville', 'Montana', 'Pretoria North'],
    'summary': 'Your custom summary text here...'
}
```

### PDF Output

Multi-section professional report with:
- Company header and branding
- Report period and metadata
- Executive summary
- Key metrics table
- Coverage areas
- Security observations (bulleted)
- Recommendations for next month
- Head of Security signature

---

## vCard Contact Export — How It Works

### What is vCard?

**vCard** (RFC 6350) is a standardized text format for storing contact information. Each contact becomes a `.vcf` file containing structured data.

### Workflow

**Step 1: Export vCard**
- Person creates contact entry (Name, Phone, Email, Title, Company)
- Export as `.vcf` file
- File contains plain-text format like:
  ```
  BEGIN:VCARD
  VERSION:3.0
  FN:P Dorfling
  TEL:+27 11 234 5678
  EMAIL:philip@sice.security
  ORG:Soft-Ice Catering Equipment
  TITLE:Head of Security
  END:VCARD
  ```

**Step 2: Import into Device**
- Recipient receives `.vcf` file (email, WhatsApp, file transfer)
- Double-click `.vcf` → Native contacts app opens automatically
- App parses fields → Creates contact entry
- **No manual entry needed** — automatic field mapping

**Step 3: Sync to All Apps**
- Contact syncs to phone's native contacts database
- WhatsApp scans contacts every ~30 seconds
- Detects new phone number → Auto-links to WhatsApp profile
- Incoming messages from that number = instant recognition
- Profile pic, status, name all appear automatically

### Why This Matters for SICE SOC

**Use Case:** Export contact cards for key personnel

```
1. Create P DORFLING vCard with:
   - Name: P DORFLING
   - Title: Head of Security
   - Company: SICE
   - Phone: +27 11 XXX XXXX
   - Email: philip@sice.security

2. Distribute .vcf to all SOC officers

3. Officers import → Phone recognizes Philip automatically
   - When emergency callsign received on WhatsApp
   - Contact name + profile pic appear instantly
   - No delay, no ambiguity, instant context

4. Benefits:
   ✅ No rekeying phone numbers across devices
   ✅ Consistent contact info across team
   ✅ WhatsApp integration automatic
   ✅ Profile sync across cloud (iCloud, Google Contacts)
```

### How to Create & Export vCards

**On Phone (iOS):**
1. Contacts app → Create new contact
2. Fill in details (name, phone, title, company)
3. Share → AirDrop or Mail as vCard
4. Recipient receives `.vcf` file

**On Phone (Android):**
1. Contacts app → Create contact
2. Fill details
3. Menu → Export as vCard
4. Send via WhatsApp, email, or Bluetooth

**On Desktop (Outlook/Apple Contacts):**
1. Right-click contact → Export
2. Save as `.vcf`
3. Share via email or file transfer

---

## Report Features Breakdown

### SICE Branding ✅

All reports include:
- **Logo:** `S` box in SICE blue (`#456BAA`)
- **Company Name:** SOFT-ICE CATERING EQUIPMENT
- **Department:** SICE Security Operations
- **Color Scheme:** SICE blue throughout (headings, accents, borders)

### Signature Footer ✅

Every report ends with:
```
— Head of Security
  P DORFLING

Soft-Ice Catering Equipment Security Operations Centre (SOC)
```

### No Callsigns ✅

Reports use professional titles only:
- ❌ Delta-6, D-6, DORF-6 (NOT in reports)
- ✅ Head of Security — P DORFLING (Professional format)

Callsigns remain internal SOC operational shorthand only.

### Dual Export ✅

**PDF:** Professional archival format for:
- Filing and record-keeping
- Formal submission to management
- Print-out distribution
- Email attachments

**WhatsApp:** Instant team communication:
- Copy-paste directly into group chats
- Emoji formatting for quick scanning
- Perfect for mobile-first operations
- No formatting loss during copy-paste

---

## Troubleshooting

### HTML Reports Won't Open

- **Solution:** Use Chrome, Firefox, Edge, or Safari
- Try: Right-click → "Open with" → Select web browser
- Ensure JavaScript is enabled (required for PDF export)

### PDF Export Not Working

- **Issue:** Browser blocked pop-ups or PDF plugin missing
- **Solution:** 
  1. Check browser pop-up settings
  2. Try a different browser
  3. Ensure internet connection (uses CDN for html2pdf library)

### Python Script Fails

- **Requirement:** Python 3.6+, ReportLab installed
- **Install:** `pip install reportlab`
- **Run:** `python3 generate_monthly_report.py 7 2026`

### WhatsApp Copy Not Working

- **Solution:** Click "📋 Copy WhatsApp Format" button
- Check clipboard (paste in Notes app to verify)
- On mobile, open WhatsApp and paste directly

---

## Best Practices

1. **Fill all fields** — Accurate data ensures professional output
2. **Use EOD Report daily** — Establish end-of-day routine
3. **Log movements immediately** — Timestamp accuracy important
4. **Archive PDFs monthly** — Build historical record
5. **Sync WhatsApp copies** — Keep team informed in real-time
6. **Update Python data** — Customize monthly metrics with actual SOC data

---

## File Locations

```
/outputs/
├── SICE_EOD_REPORT.html                 ← Daily EOD reports
├── SICE_MOVEMENT_LOG.html               ← Movement documentation
├── generate_monthly_report.py           ← Monthly summary generator
├── SICE_Monthly_Report_2026_07.pdf      ← Sample July 2026 report
└── README_REPORT_GENERATORS.md          ← This guide
```

---

## Support & Customization

**Questions?**
- Review the on-page instructions in each HTML report
- Check the Python script comments for customization points
- Refer to vCard standard (RFC 6350) for export details

**Customize colors/branding:**
- Edit CSS variables in HTML files: `--sice-blue: #456BAA`
- Modify reportlab colors in Python script
- Keep professional appearance consistent

---

**Last Updated:** 22 July 2026  
**Prepared By:** Head of Security — P DORFLING  
**SICE Security Operations Centre (SOC)**

---
