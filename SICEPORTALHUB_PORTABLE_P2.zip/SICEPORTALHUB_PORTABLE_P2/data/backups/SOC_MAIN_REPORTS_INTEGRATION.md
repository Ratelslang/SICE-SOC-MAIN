# Adding Reports Menu to SOC MAIN Portal

**Step-by-step instructions to add Reports as a top menu item**

---

## What You'll Get

A "📊 REPORTS" menu at the top of SOC MAIN that opens the Reports Hub with all tools.

---

## Step 1: Find the Menu Section in SICE_SOC_MAIN.html

Open `SICE_SOC_MAIN.html` in a text editor.

Look for this section (around line 280-310):

```html
<!-- ---- HEADER MENU BAR ---- -->
<div class="ws-bar">
  <div class="ws-title">SICE SOC OPS</div>
  <button class="btn" onclick="closeWorkspace()">← Back to Portal</button>
</div>
```

---

## Step 2: Add Reports Button to Menu

**BEFORE** (current):
```html
<div class="ws-bar">
  <div class="ws-title">SICE SOC OPS</div>
  <button class="btn" onclick="closeWorkspace()">← Back to Portal</button>
</div>
```

**AFTER** (add Reports):
```html
<div class="ws-bar">
  <div class="ws-title">SICE SOC OPS</div>
  <button class="btn" onclick="openReportsHub()">📊 REPORTS</button>
  <button class="btn" onclick="closeWorkspace()">← Back to Portal</button>
</div>
```

---

## Step 3: Add JavaScript Function

Find the `<script>` section at the bottom of SICE_SOC_MAIN.html.

Look for functions like `closeWorkspace()` or `loadWorkspace()`.

**Add this function after them:**

```javascript
function openReportsHub() {
    const workspace = document.getElementById('workspace');
    const wsTitle = workspace.querySelector('.ws-title');
    
    wsTitle.textContent = '📊 Reports Hub';
    
    let iframe = workspace.querySelector('iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.style.border = 'none';
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        workspace.appendChild(iframe);
    }
    
    iframe.src = 'SICE_REPORTS_HUB.html';
    workspace.classList.add('active');
}
```

---

## Step 4: File Placement

Make sure these files are in the **same folder** as SICE_SOC_MAIN.html:

```
SOC Folder/
├── SICE_SOC_MAIN.html              (Main portal)
├── SICE_REPORTS_HUB.html           ← Add this
├── SICE_EOD_REPORT.html            ← Already there
├── SICE_MOVEMENT_LOG.html          ← Already there
├── generate_monthly_report_TEMPLATE.py ← Already there
├── OPS_.html                       (Existing)
├── SICE_CLOCK_MODULE.html          (Existing)
└── Other modules...
```

---

## Step 5: Test It

1. **Save SICE_SOC_MAIN.html**

2. **Open SICE_SOC_MAIN.html** in your browser

3. **Look at the top** — you should see:
   ```
   SICE SOC OPS    [📊 REPORTS]  [← Back to Portal]
   ```

4. **Click "📊 REPORTS"** — Reports Hub opens in iframe ✓

---

## How It Works

**Top Menu:**
```
[SICE SOC OPS Title] [📊 REPORTS] [← Back to Portal]
```

**Click "📊 REPORTS":**
- Reports Hub loads (SICE_REPORTS_HUB.html)
- Shows 4 cards:
  - 🔒 End-of-Day Report
  - 🛡️ Movement Log
  - 📊 Monthly Summary
  - 👥 Contact Manager
  - 📋 Quick Start Guide
  - 📖 Full Documentation

**From Reports Hub:**
- Click EOD Report → Opens in new window
- Click Movement Log → Opens in new window
- Click Monthly Summary → Shows instructions
- Click Contact Manager → Download vCards
- Click Guides → Opens documentation

---

## Alternative: Add as Carousel Card (Optional)

If you want Reports as a carousel card instead of top menu:

Find the carousel cards section (around line 403-445) and add:

```html
<div class="option-card" onclick="openReportsHub()">
    <div class="option-icon">📊</div>
    <div class="option-name">Reports Hub</div>
    <div class="option-desc">Daily EOD reports, movement logs, monthly summary, and contact manager.</div>
    <div class="option-tags">
        <span class="option-tag">Reports</span>
        <span class="option-tag">Daily</span>
        <span class="option-tag">Export</span>
    </div>
    <div class="option-go">Launch →</div>
</div>
```

Then use the same `openReportsHub()` function above.

---

## Troubleshooting

**"📊 REPORTS button doesn't work"**
- Make sure `openReportsHub()` function is added to the script
- Check that SICE_REPORTS_HUB.html is in the same folder
- Open browser console (F12) and check for errors

**"Reports Hub opens but buttons don't work"**
- Check that SICE_EOD_REPORT.html and SICE_MOVEMENT_LOG.html exist
- Verify filenames match exactly (case-sensitive)

**"Reports Hub looks broken"**
- Try different browser (Chrome, Firefox, Safari)
- Check that all files are in the same folder
- Clear browser cache and reload

---

## Testing Checklist

After adding Reports menu:

- [ ] "📊 REPORTS" button visible in top menu
- [ ] Click button → Reports Hub loads in iframe
- [ ] Reports Hub title shows at top
- [ ] Can see all 4 report cards
- [ ] Click "Open Report" → Opens EOD or Movement Log
- [ ] Click "Generate Report" → Shows monthly instructions
- [ ] Click "Manage Contacts" → Shows vCard download buttons
- [ ] Click vCard download → File downloads
- [ ] Back button works → Returns to Portal

---

## If You Want It Disabled/Hidden

To hide the Reports button initially and enable later:

```javascript
function enableReportsMenu() {
    const btn = document.querySelector('[onclick="openReportsHub()"]');
    if (btn) btn.style.display = 'block';
}
```

Or add to a menu:
```html
<button class="btn" onclick="enableReportsMenu(); this.style.display='none';">
    Enable Reports
</button>
```

---

## Summary

**What to do:**
1. Open SICE_SOC_MAIN.html in text editor
2. Find the menu bar (around line 280-310)
3. Add: `<button class="btn" onclick="openReportsHub()">📊 REPORTS</button>`
4. Scroll to bottom, find `</script>`
5. Paste the `openReportsHub()` function before it
6. Save file
7. Test in browser

**That's it!** Reports menu now works in your SOC MAIN portal.

---

**For detailed integration help:** See INTEGRATION_GUIDE.md

**Files needed:**
- ✅ SICE_REPORTS_HUB.html
- ✅ SICE_EOD_REPORT.html
- ✅ SICE_MOVEMENT_LOG.html
- ✅ generate_monthly_report_TEMPLATE.py
- ✅ 4 vCard files (WILLEM_PALMER.vcf, etc)

All in outputs folder → Copy to SOC folder → Done!

---
