# vCard Import Guide — SICE Principals

**4 vCard files created for Willem Palmer family**

---

## What Are These Files?

These are contact files (`.vcf` format) that contain all the information:
- Name, Phone, Email
- Title, Company
- Date of Birth
- Address
- Callsigns (Whiskey-1, Golf-1, etc)

---

## How to Import into Your Phone

### **On Android Phone:**

1. **Download the .vcf files** to your phone (via email, WhatsApp, or file transfer)

2. **Open a .vcf file:**
   - Use Files app → Locate the `.vcf` file
   - Tap it → Select "Open with Contacts"
   - Or: Drag-and-drop into Contacts app

3. **Contacts app asks:** "Import this contact?"
   - Tap **IMPORT**
   - Contact saved immediately ✓

4. **Repeat for all 4 files:**
   - WILLEM_PALMER.vcf
   - GERALDINE_PALMER.vcf
   - GISSELLE_PIENAAR.vcf
   - JESSICA_PALMER.vcf

**Result:** All 4 contacts appear in your phone's Contacts app with full details

---

### **On iPhone:**

1. **Open email or file sharing app** with the `.vcf` file

2. **Tap the attachment** → Choose "More" → "Add to Contacts"

3. **Confirm** → Contact added ✓

4. **Repeat for each `.vcf` file**

---

### **Via Email (Easiest):**

1. **Email yourself the `.vcf` files**
2. **On phone:** Open email → Tap `.vcf` attachment
3. **Phone detects it:** "Add to Contacts?" → Yes
4. **Done!** Contact imported with all info

---

## What Happens After Import?

✅ **Automatic WhatsApp Linking:**
- Contact syncs to phone's Contacts database
- WhatsApp scans contacts every ~30 seconds
- Detects Willem's number → Auto-links to his WhatsApp profile
- Next message from Willem → His name + profile pic appear instantly

✅ **Emergency Recognition:**
- Incoming call from Willem → Callsign shows (Whiskey-1 in note)
- You know instantly who's calling
- Same for Geraldine (Golf-1), Gisselle (Zulu-1), Jessica (Juliet-1)

✅ **Backup to Cloud:**
- Contact syncs to Google Contacts (Android) or iCloud (iPhone)
- Safe backup if phone is lost
- Accessible from desktop too

---

## The 4 Contacts

| Name | Callsign | Title | Phone | Email |
|------|----------|-------|-------|-------|
| **Willem Palmer** | Whiskey-1 | CEO / Main Principal | +27 82 922 1112 | info@cateringequipment.co.za |
| **Geraldine Palmer** | Golf-1 | CEO PA / Secondary Principal | +27 72 617 7757 | geraldine@cateringequipment.co.za |
| **Gisselle Pienaar** | Zulu-1 | Secondary Principal | +27 79 511 6367 | — |
| **Jessica Palmer** | Juliet-1 | Secondary Principal | +27 76 530 5279 | — |

---

## Distributing to Team

Want to share these with other SOC officers?

1. **Email the .vcf files** to team members
2. **Or upload to shared folder** (Syncthing, CIFS share)
3. **Each officer imports** to their phone
4. **Result:** Entire team recognizes principals instantly on calls/WhatsApp

---

## Key Benefit

**Before vCard:**
- Officer receives call from unknown number
- Has to manually search phone to see who it is
- Could miss urgent principal call

**After vCard:**
- Officer's phone shows: "Whiskey-1 calling" instantly
- Picture + name appear
- Knows immediately it's the CEO
- Can prioritize response ✓

---

**Files Ready to Import:**
- ✅ WILLEM_PALMER.vcf
- ✅ GERALDINE_PALMER.vcf
- ✅ GISSELLE_PIENAAR.vcf
- ✅ JESSICA_PALMER.vcf

Download them and import to your phone now!

---
