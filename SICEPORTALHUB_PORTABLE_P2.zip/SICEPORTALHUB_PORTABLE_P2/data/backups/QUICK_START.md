# SICE Report Generators — Quick Start Guide

**Everything you need to know in 5 minutes**

---

## What You Got

| File | Purpose | Use |
|------|---------|-----|
| **SICE_EOD_REPORT.html** | Daily end-of-day security report | Open in browser, fill form, export PDF or copy WhatsApp |
| **SICE_MOVEMENT_LOG.html** | Personnel movement tracking | Document where officers went, when, why, and duration |
| **generate_monthly_report.py** | Monthly security summary | Run: `python3 generate_monthly_report.py 7 2026` |
| **README_REPORT_GENERATORS.md** | Complete user guide | Read for detailed instructions |
| **INTEGRATION_GUIDE.md** | How to embed in Portal Hub | Add to SOC MAIN carousel or run standalone |

---

## 1-Minute Start

### EOD Report (End of Day)

1. **Open:** Double-click `SICE_EOD_REPORT.html`
2. **Fill:**
   - Set today's date ✅ auto-fills
   - Set time secured (when you locked up)
   - Check premises status (Gates, Alarm, CCTV, Incidents)
3. **Export:**
   - **PDF:** Click "📥 Export as PDF" → saves as PDF file
   - **WhatsApp:** Click "📋 Copy WhatsApp Format" → paste into WhatsApp group

**Example WhatsApp:**
```
🔒 *END OF DAY SECURITY REPORT*
📅 *Date:* Wednesday, 22 July 2026
🕐 *Time Secured:* 14:25

🏭 *Premises Status*
• Gates & Doors: All secure ✅
• Alarm: Yes — Alarm Armed ✅
• CCTV: Yes — CCTV Active ✅
• Incidents: None ✅

✅ *Soft-Ice Catering Equipment premises are secured and safe.*

— Head of Security
  P DORFLING
```

### Movement Log (Tracking)

1. **Open:** Double-click `SICE_MOVEMENT_LOG.html`
2. **Fill:**
   - Date, Purpose (Work/Emergency/etc), Reason (e.g., "School Run")
   - Who requested it, who's going
   - Where leaving from, where going to
   - Times (departure/arrival) → Duration calculates automatically ✅
3. **Export:** Same as EOD (PDF or WhatsApp)

### Monthly Report (Summary)

1. **Run command:**
   ```bash
   python3 generate_monthly_report.py 7 2026
   ```
   Creates: `SICE_Monthly_Report_2026_07.pdf`

2. **Customize:**
   - Open `generate_monthly_report.py` in text editor
   - Change `sample_data` dict with your actual metrics
   - Re-run command

---

## Key Features

✅ **SICE Branding**
- Company logo (S box in SICE blue)
- Professional dark theme
- All color-coded with SICE blue (#456BAA)

✅ **PDF Export**
- Professional format for filing
- Print-ready
- Includes signature: "Head of Security — P DORFLING"

✅ **WhatsApp Copy-Paste**
- Formatted with emojis for quick scanning
- Copies to clipboard with one click
- Paste directly into group chats
- No format loss

✅ **No Callsigns in Reports**
- Reports use "Head of Security" not "Delta-6"
- Clean, professional format
- Callsigns stay internal only

✅ **Mobile Optimized**
- Works on phones, tablets, desktops
- Touch-friendly buttons
- Responsive design

✅ **Data Persistence**
- Form data saves to browser (localStorage)
- Picks up where you left off
- Won't lose work if browser closes

---

## vCard Contact Export (Bonus)

**What:** Export officer contact info as .vcf file  
**Why:** Recipients import → Contact auto-syncs to phone/WhatsApp  
**How:**

1. Create contact (Name, Phone, Title, Company, Email)
2. Export as `.vcf` file (right-click → Export)
3. Send to team (email, WhatsApp, file transfer)
4. Recipients receive `.vcf` → Double-click → Contacts app opens
5. Auto-creates contact with all info pre-filled
6. WhatsApp recognizes phone number → Instant profile linking

**For SICE:**
```
Create: P DORFLING
Phone: +27 11 XXX XXXX
Title: Head of Security
Company: Soft-Ice Catering Equipment
Email: philip@sice.security

Export as .vcf → Distribute to all SOC officers
When officer calls on WhatsApp → Name + profile appear instantly
```

---

## File Storage

```
Your outputs folder:
├── SICE_EOD_REPORT.html           ← Use this daily
├── SICE_MOVEMENT_LOG.html         ← Use for site visits
├── generate_monthly_report.py     ← Run monthly
├── SICE_Monthly_Report_2026_07.pdf ← Sample output
├── README_REPORT_GENERATORS.md    ← Full guide
├── INTEGRATION_GUIDE.md           ← Portal Hub setup
└── QUICK_START.md                 ← This file
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| HTML won't open | Use Chrome/Firefox/Safari (any modern browser) |
| PDF export fails | Check internet (uses CDN), try different browser |
| WhatsApp copy not working | Click button, paste in Notes app to verify clipboard |
| Python script errors | Run: `pip install reportlab`, then try again |
| Form data lost | Browser cache cleared; refresh page |
| Can't find files | Check your Downloads folder or outputs folder |

---

## Integration (Optional)

Want to add these to your SOC MAIN portal?

**Simple method:**
1. Copy `.html` files to same folder as SICE_SOC_MAIN.html
2. Add as new carousel cards in portal
3. Click card → opens report generator in iframe
4. Works from ghost machine and office WiFi

See **INTEGRATION_GUIDE.md** for detailed setup code.

---

## Best Practices

1. **Use daily:** EOD report at end of every shift
2. **Log immediately:** Movement logs right when officer leaves/arrives
3. **Archive PDFs:** Save monthly reports for compliance
4. **Share via WhatsApp:** Keep team informed real-time
5. **Backup data:** Copy PDF files to secure folder monthly
6. **Customize metrics:** Update Python script with your actual SOC data

---

## Support

**Questions?**

1. Read **README_REPORT_GENERATORS.md** (detailed user guide)
2. Check **INTEGRATION_GUIDE.md** (if adding to Portal Hub)
3. Open `.html` file in browser and look at on-page instructions
4. Check Python script comments for customization points

---

## Key Info

- **Reports use:** SICE blue (`#456BAA`), dark theme, professional signature
- **Data is:** Stored locally in browser, never uploaded
- **Export is:** Client-side rendering (no server needed except PDF CDN)
- **Works:** Online or offline (except PDF export needs internet)
- **Mobile:** Fully responsive, touch-optimized
- **Security:** No auth tokens, no tracking, completely private

---

## One More Thing: vCard Workflow

```
1. Create contact in phone
   ↓
2. Export as .vcf file
   ↓
3. Send .vcf to team (email/WhatsApp/file)
   ↓
4. Team member receives .vcf
   ↓
5. Double-click .vcf → Auto-imports to Contacts
   ↓
6. Contact syncs to phone + WhatsApp
   ↓
7. Next call from that number → Name appears instantly
   ✅ Problem solved: No rekeying, instant recognition
```

---

**Ready to use?**

1. Open `SICE_EOD_REPORT.html` in your browser → Start using today
2. Try the WhatsApp copy feature → Share with team
3. Export a PDF → See how it looks
4. Check INTEGRATION_GUIDE.md if you want to add to Portal Hub

**Questions?** See README_REPORT_GENERATORS.md for complete details.

---

**Prepared By:** Head of Security — P DORFLING  
**Date:** 22 July 2026  
**Organization:** SICE Security Operations Centre
