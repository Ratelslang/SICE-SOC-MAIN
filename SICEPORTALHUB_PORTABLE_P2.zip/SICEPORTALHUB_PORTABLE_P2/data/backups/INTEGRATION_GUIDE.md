# SICE Report Generators — Portal Hub Integration Guide

**How to embed EOD and Movement Log reports into your SOC MAIN portal**

---

## Quick Start

Three report tools are now available for integration into your SICE Portal Hub:

1. **SICE_EOD_REPORT.html** — Standalone report generator (can embed via iframe)
2. **SICE_MOVEMENT_LOG.html** — Standalone report generator (can embed via iframe)
3. **generate_monthly_report.py** — Command-line monthly report builder

All use SICE blue branding (`#456BAA`) and include:
- ✅ PDF export functionality
- ✅ WhatsApp copy-paste format
- ✅ Professional "Head of Security — P DORFLING" signature
- ✅ Dark theme matching your Portal Hub aesthetic
- ✅ Mobile-optimized responsive design

---

## Option 1: Standalone Use (Simplest)

Simply open each HTML file directly in a browser tab:

```
1. Open SICE_EOD_REPORT.html
2. Fill in end-of-day details
3. Export as PDF or copy WhatsApp format
4. Done — no integration needed
```

**Advantages:**
- Zero setup required
- Works offline (except PDF export needs internet)
- Can run on any device with a browser
- Data stored in browser localStorage (persistent)

**Where to store:**
- Same folder as SICE_SOC_MAIN.html
- Access via file:// or serve via sice_server.py

---

## Option 2: Embed in SOC MAIN (Intermediate)

Add these as carousel modules or tabs in your Portal Hub:

### 2A. Add to SOC MAIN Carousel

In your `SICE_SOC_MAIN.html`, add a new carousel option:

```javascript
// In your option-card carousel array, add:
{
    icon: '📝',
    name: 'EOD Reports',
    desc: 'End-of-day security report generator',
    tags: ['Daily', 'Export', 'WhatsApp'],
    href: 'javascript:openEODReport()'
}

// Then add this function:
function openEODReport() {
    // Option A: Open in embedded workspace iframe
    loadWorkspaceApp('SICE_EOD_REPORT.html', 'EOD Report');
    
    // Option B: Open in new window
    // window.open('SICE_EOD_REPORT.html', 'EOD_Report', 'width=1000,height=900');
}

function loadWorkspaceApp(appPath, appName) {
    const workspace = document.getElementById('workspace');
    const iframe = workspace.querySelector('iframe');
    
    workspace.classList.add('active');
    document.querySelector('.ws-title').textContent = appName;
    iframe.src = appPath;
}
```

### 2B. HTML Snippet to Add

Add this to your `SICE_SOC_MAIN.html` carousel section:

```html
<div class="option-card">
    <div class="option-icon">📝</div>
    <div class="option-name">EOD Reports</div>
    <div class="option-desc">Generate end-of-day security reports. Export as PDF or copy to WhatsApp for team updates.</div>
    <div class="option-tags">
        <span class="option-tag">Daily</span>
        <span class="option-tag">Export</span>
        <span class="option-tag">WhatsApp</span>
    </div>
    <div class="option-go" onclick="openReportApp('SICE_EOD_REPORT.html', 'EOD Report')">
        Launch →
    </div>
</div>

<div class="option-card">
    <div class="option-icon">🛡️</div>
    <div class="option-name">Movement Logs</div>
    <div class="option-desc">Document personnel movement between locations. Auto-calculate duration, export PDF or WhatsApp.</div>
    <div class="option-tags">
        <span class="option-tag">Movement</span>
        <span class="option-tag">Tracking</span>
        <span class="option-tag">Export</span>
    </div>
    <div class="option-go" onclick="openReportApp('SICE_MOVEMENT_LOG.html', 'Movement Log')">
        Launch →
    </div>
</div>
```

### 2C. JavaScript to Add

Add this function to your `SICE_SOC_MAIN.html` script section:

```javascript
function openReportApp(appPath, appName) {
    const workspace = document.getElementById('workspace');
    
    // Ensure workspace exists
    if (!workspace) {
        console.error('Workspace not found');
        return;
    }
    
    // Update workspace title
    const wsTitle = workspace.querySelector('.ws-title');
    if (wsTitle) wsTitle.textContent = appName;
    
    // Load iframe
    let iframe = workspace.querySelector('iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.style.border = 'none';
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        workspace.appendChild(iframe);
    }
    iframe.src = appPath;
    
    // Show workspace
    workspace.classList.add('active');
    
    // Add back button listener
    const backBtn = workspace.querySelector('.ws-btn-back');
    if (backBtn) {
        backBtn.onclick = closeReportApp;
    }
}

function closeReportApp() {
    const workspace = document.getElementById('workspace');
    if (workspace) {
        workspace.classList.remove('active');
    }
}
```

---

## Option 3: Server-Side Integration (Advanced)

### 3A. Using sice_server.py

If you're running `sice_server.py`, add routes for the report generators:

```python
# In your sice_server.py, add this route:

@app.route('/api/generate-monthly-report', methods=['POST'])
def generate_monthly_report():
    """Generate monthly security report PDF"""
    data = request.json
    month = data.get('month', datetime.now().month)
    year = data.get('year', datetime.now().year)
    
    filename = f'SICE_Monthly_Report_{year}_{month:02d}.pdf'
    filepath = f'/home/claude/reports/{filename}'
    
    # Call generate_monthly_report.py
    import subprocess
    subprocess.run(['python3', 'generate_monthly_report.py', str(month), str(year)])
    
    return {
        'status': 'success',
        'filename': filename,
        'path': filepath,
        'download_url': f'/downloads/{filename}'
    }
```

### 3B. Add Report API to Portal Hub

Add fetch calls to your Portal Hub:

```javascript
async function requestMonthlyReport(month, year) {
    try {
        const response = await fetch('http://localhost:8743/api/generate-monthly-report', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ month, year })
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            // Show download link
            console.log(`Report ready: ${result.download_url}`);
            window.open(result.download_url, '_blank');
        }
    } catch (error) {
        console.error('Report generation failed:', error);
    }
}

// Usage:
// requestMonthlyReport(7, 2026);
```

---

## Option 4: WhatsApp Automation (Advanced)

### Auto-Send Reports to WhatsApp

If you have the WhatsApp MCP bridge running (`whatsapp-mcp.exe`), you can auto-send reports:

```javascript
async function sendEODToWhatsApp(messageText) {
    """
    Send EOD report via WhatsApp MCP bridge
    Requires: whatsapp-mcp running on http://127.0.0.1:8765/mcp
    """
    
    try {
        const response = await fetch('http://127.0.0.1:8765/mcp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                tool: 'whatsapp:send_message',
                input: {
                    chat: 'Myne Private',
                    message: messageText
                }
            })
        });
        
        const result = await response.json();
        console.log('Message sent:', result);
        return result;
    } catch (error) {
        console.error('WhatsApp send failed:', error);
    }
}

// Usage in EOD Report:
// sendEODToWhatsApp(generateWhatsAppFormat());
```

---

## File Locations & Deployment

### Development Setup

```
SOC Folder/
├── SICE_SOC_MAIN.html           (Portal Hub - main file)
├── SICE_EOD_REPORT.html         (Add this)
├── SICE_MOVEMENT_LOG.html       (Add this)
├── generate_monthly_report.py   (Add this)
├── OPS_.html                    (Existing)
├── SICE_CLOCK_MODULE.html       (Existing)
└── manifest.json
```

### Tailscale/Remote Access

If running on Windows ghost machine (`100.122.17.120:8743`):

```
http://100.122.17.120:8743/SICE_EOD_REPORT.html
http://100.122.17.120:8743/SICE_MOVEMENT_LOG.html
```

### Local Office WiFi

If running on office network (`192.168.0.145:8743`):

```
http://192.168.0.145:8743/SICE_EOD_REPORT.html
http://192.168.0.145:8743/SICE_MOVEMENT_LOG.html
```

---

## localStorage Data Persistence

Both HTML report generators use browser `localStorage` to save data:

```javascript
// Each report autosaves form data to localStorage
localStorage.setItem('sice_eod_draft', JSON.stringify(formData));
localStorage.setItem('sice_movement_draft', JSON.stringify(formData));

// Data persists between sessions (until user clears cache)
// Clearing browser cache/storage will reset the forms
```

To add data sync across devices (via Syncthing):

```javascript
function syncReportDataToServer() {
    const draftData = localStorage.getItem('sice_eod_draft');
    
    fetch('http://localhost:8743/api/save-draft', {
        method: 'POST',
        body: JSON.stringify({ data: draftData })
    });
}

// Call periodically:
// setInterval(syncReportDataToServer, 30000); // Every 30 seconds
```

---

## Customization

### Change SICE Blue Color

Edit the CSS variable in both HTML files:

```css
:root {
    --sice-blue: #456BAA;        /* Change this hex code */
    --sice-blue-light: #6B8FCC;
    --sice-blue-dark: #2F4A7A;
}
```

### Add Custom Company Logo

In the HTML reports, replace the `S` logo box:

```html
<!-- Current: -->
<div class="logo-box">S</div>

<!-- Replace with image: -->
<img src="logo.png" width="50" height="50" />
```

### Modify Signature Line

In both HTML files, update:

```javascript
// Change signature in footer from:
"— Head of Security\n  P DORFLING"

// To custom text:
"— Operations Manager\n  [Your Name]"
```

### Update Company Name

In header section:

```html
<!-- Change from: -->
<div class="company-name">SOFT-ICE CATERING EQUIPMENT</div>

<!-- To: -->
<div class="company-name">YOUR COMPANY NAME</div>
```

---

## Testing Checklist

- [ ] HTML files open in browser (Chrome, Firefox, Safari, Edge)
- [ ] PDF export works (requires internet for html2pdf CDN)
- [ ] WhatsApp format copy button works (check clipboard)
- [ ] Form data persists after refresh (localStorage working)
- [ ] Responsive design works on mobile (resize window)
- [ ] Date/time fields populate correctly
- [ ] Duration calculation works for movement logs
- [ ] Footer signature displays correctly
- [ ] SICE blue branding consistent across all sections
- [ ] Dark theme doesn't have contrast issues

---

## Troubleshooting Integration

### Reports Won't Load in iframe

**Issue:** CORS policy blocking
**Solution:** 
```javascript
// Use relative paths instead of absolute:
iframe.src = './SICE_EOD_REPORT.html';  // ✅ Works
// NOT:
iframe.src = 'http://192.168.0.145:8743/SICE_EOD_REPORT.html';
```

### PDF Export Fails

**Issue:** CDN unavailable or browser security
**Solution:**
1. Check internet connection
2. Disable ad blocker (blocks CDN scripts)
3. Use different browser
4. Check browser console for errors (F12)

### WhatsApp Format Shows Special Characters

**Issue:** Encoding mismatch
**Solution:**
```javascript
// Ensure UTF-8 encoding:
const msg = generateWhatsAppFormat().trim();
const blob = new Blob([msg], { type: 'text/plain;charset=utf-8' });
navigator.clipboard.writeText(msg);
```

---

## Performance Notes

- **HTML reports:** ~20KB each, loads instantly
- **PDF generation:** 1-3 seconds (CDN-dependent)
- **Monthly script:** ~2 seconds to generate PDF (Python)
- **localStorage:** ~50KB storage limit (plenty for form data)

---

## Security Considerations

### Data Privacy

- Form data stored in browser localStorage only
- No data sent to external servers (except PDF CDN)
- Reports contain no authentication tokens
- Safe to use on any connected device

### Export Security

- PDF export uses client-side rendering (no server upload)
- WhatsApp copy is manual (user controls when to share)
- No automatic data logging or tracking

### Recommendations

1. **Access Control:** Restrict HTML files to SOC personnel only
2. **Encryption:** Store archived PDFs in encrypted folder
3. **Audit Trail:** Log all report exports in SOC system
4. **Backup:** Archive monthly reports to secure storage

---

## Support & Questions

**If reports don't work:**

1. Check browser console (F12 → Console tab)
2. Verify JavaScript is enabled
3. Try clearing browser cache
4. Test in different browser
5. Check file paths and URLs

**For Portal Hub integration:**

1. Verify SOC MAIN.html carousel structure matches code examples
2. Test iframe loading with simple test.html first
3. Check browser console for iframe errors
4. Verify relative file paths

**For Python script:**

1. Ensure Python 3.6+ installed
2. Verify reportlab: `python3 -c "import reportlab"`
3. Run in directory with write permissions
4. Check output folder exists

---

## Next Steps

1. **Copy files** to your Portal Hub folder
2. **Test standalone** — Open each HTML file in browser
3. **Verify exports** — Export PDF and copy WhatsApp format
4. **Integrate** — Add to SOC MAIN carousel (Option 2)
5. **Deploy** — Push to ghost machine or office network
6. **Document** — Add to your SOC operations manual

---

**Prepared By:** Head of Security — P DORFLING  
**Date:** 22 July 2026  
**Organization:** Soft-Ice Catering Equipment Security Operations Centre (SOC)

---
