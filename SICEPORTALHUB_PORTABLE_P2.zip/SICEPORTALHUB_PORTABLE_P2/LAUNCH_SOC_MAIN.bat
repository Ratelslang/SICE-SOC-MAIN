@echo off
REM ============================================================
REM SICE SOC PORTAL — PORTABLE WINDOWS LAUNCHER
REM Starts the local service required for the PWA, status mirror,
REM traffic panel, and inline module routing; then opens the portal.
REM ============================================================
setlocal
cd /d "%~dp0"

if not exist "RUN_SICE_PORTAL.py" (
    echo.
    echo ERROR: RUN_SICE_PORTAL.py is missing.
    echo Keep this launcher in the complete extracted SICE SOC portal folder.
    echo.
    pause
    exit /b 1
)

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 RUN_SICE_PORTAL.py
    goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
    python RUN_SICE_PORTAL.py
    goto :done
)

echo.
echo ERROR: Python 3 was not found.
echo Install Python 3 from https://www.python.org/downloads/ and run this launcher again.
echo During installation, select "Add Python to PATH".
echo.
pause
exit /b 1

:done
exit /b %errorlevel%
