# SICE SOC Main Portal — P2 Command Desk Upgrade

## Scope

This release delivers a **non-disruptive visual and workflow upgrade** for `SICE_SOC_MAIN.html`. The existing authentication approach, local service routes, localStorage keys, data collections, PWA start page, inline workspace loader, module files, and hosted-MAIN-SOC link remain unchanged.

The visual approach is an **operator-first dark-glass command desk** that keeps the existing charcoal and steel house style while making the operational picture and most-used routes available before the legacy module carousel.

## What Changed

| Area | Upgrade | Operational Effect |
|---|---|---|
| Command picture | Added four live metric cards for open hazards, flagged 24-hour events, keys outstanding, and expiry watch items. | An operator can assess the current priority picture without opening several modules. |
| Priority workspaces | Added direct launches for Security OPS, Incident Desk, Intel Hub, Movement Log, Key Control, Fleet & Movement, Asset Management, Safety & Health, and CP Ops Planner. | Routine SOC actions require fewer clicks than the carousel-first route. |
| Command queue | Added one-click access to the existing JOC, cross-module Activity Feed, and consolidated Expiry Watchlist panels. | Triage uses the portal's existing data and panel workflows rather than creating a parallel dashboard. |
| Legacy access | Retained the existing carousel as a collapsed **Module deck**. | The full application catalogue remains accessible but no longer dominates the first operational view. |
| Accessibility | Added keyboard-focus states, visible button behavior, descriptive control labels, reduced-motion handling, responsive grids, and mobile two-column module cards. | The desk is more usable with keyboard and field-device workflows. |
| PWA delivery | Bumped the service-worker cache release from `sice-soc-v17` to `sice-soc-v18-command-desk`. | Installed clients can receive the new main portal rather than retaining the prior cached page. |

## Preserved Integrations

The following interfaces were intentionally left intact:

| Interface | Status |
|---|---|
| Browser login and current session keys | Unchanged |
| Local service endpoints and NOC checks | Unchanged |
| SOC MAIN status mirror and traffic-alert route | Unchanged |
| Existing localStorage keys and module data model | Unchanged |
| Inline iframe workspace and module file routes | Unchanged |
| Hosted MAIN SOC launch target | Unchanged |
| Existing JOC, Activity Feed, Expiry Watchlist, and search functions | Reused by the new command desk |

## Validation Record

| Check | Result |
|---|---|
| Main portal JavaScript syntax check | Passed |
| Isolated workflow test | Passed: 8 of 8 checks |
| Command Desk and live metric rendering | Passed |
| JOC, Activity Feed, and Expiry Watchlist command-queue actions | Passed |
| Legacy module deck expand action | Passed |
| Existing inline module workspace launch | Passed |
| Desktop visual rendering | Reviewed at 1440 × 1400 |
| Narrow field-device rendering | Reviewed at 390 × 1500 |
| Application-code diff from supplied portal | Limited to `SICE_SOC_MAIN.html` and `sw.js` |

## Operator Use

After sign-in, use the **Command Desk** as the default operational starting point. The highlighted metric cards indicate records requiring attention. Use **Priority workspaces** for direct launches, **Command queue** for triage panels, and **Module deck** when a less-frequent legacy module is needed.

## Deployment

Replace the existing `SICE_SOC_MAIN.html` and `sw.js` with the upgraded versions as a matched pair. Start the portal through the existing launcher. On already-installed PWA clients, close and reopen the app after the first successful update so the new service-worker cache can activate.

> This P2 release deliberately does not change authentication, API exposure, LAN binding, or record persistence. Those items remain appropriate candidates for a separately approved P1 security-hardening release.
