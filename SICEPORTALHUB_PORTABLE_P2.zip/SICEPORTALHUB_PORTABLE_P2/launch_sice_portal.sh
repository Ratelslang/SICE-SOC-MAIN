#!/usr/bin/env bash
# ============================================================
# SICE SOC PORTAL — PORTABLE LINUX LAUNCHER
# Starts the local service required for the PWA, status mirror,
# traffic panel, and inline module routing; then opens the portal.
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is required but was not found."
  exit 1
fi

exec python3 "$SCRIPT_DIR/RUN_SICE_PORTAL.py"
