#!/usr/bin/env python3
"""Portable SICE SOC Portal launcher.

Starts the bundled local service from the folder containing this file and opens
SICE_SOC_MAIN.html in the default browser. Python 3 standard library only.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
PORT = 8743
BASE_URL = f"http://127.0.0.1:{PORT}"
HEALTH_URL = f"{BASE_URL}/health"
PORTAL_URL = f"{BASE_URL}/SICE_SOC_MAIN.html"
LOG_PATH = Path(os.environ.get("TEMP") or os.environ.get("TMPDIR") or "/tmp") / "sice_soc_portal_server.log"


def service_is_ready() -> bool:
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=1.5) as response:
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("service") == "sice_server"
    except Exception:
        return False


def main() -> int:
    server_script = ROOT / "sice_server.py"
    portal_file = ROOT / "SICE_SOC_MAIN.html"
    if not server_script.is_file() or not portal_file.is_file():
        print("ERROR: Run this launcher from the complete extracted SICE SOC portal folder.")
        return 1

    if service_is_ready():
        print("SICE SOC local service is already running. Opening the portal…")
        webbrowser.open(PORTAL_URL, new=1)
        return 0

    creation_flags = 0
    if os.name == "nt":
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS

    print(f"Starting SICE SOC local service from: {ROOT}")
    with LOG_PATH.open("a", encoding="utf-8") as log:
        subprocess.Popen(
            [sys.executable, str(server_script)],
            cwd=str(ROOT),
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            creationflags=creation_flags,
            start_new_session=(os.name != "nt"),
        )

    for _ in range(20):
        time.sleep(0.25)
        if service_is_ready():
            print(f"SICE SOC is ready: {PORTAL_URL}")
            webbrowser.open(PORTAL_URL, new=1)
            return 0

    print("ERROR: The local service did not start on port 8743.")
    print(f"Check the log file: {LOG_PATH}")
    print("If another program uses port 8743, close it and run this launcher again.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
