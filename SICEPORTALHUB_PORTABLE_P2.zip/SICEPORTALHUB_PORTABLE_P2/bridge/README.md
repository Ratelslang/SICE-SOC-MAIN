# Linux SOC MAIN Bridge

The bridge runs on the Linux machine hosting the SICE Portal. It watches the existing `data/soc_main/status.json` mirror written by `sice_server.py` and sends changed shared activity, incidents, patrols, hazards, inspections, and key-status records to the protected War Room webhook. Each record has a stable external identifier; retrying a previously accepted record is safe because the hosted endpoint records the receipt and ignores duplicates.

## First-time installation

Install the companion `SICE_SOC_MAIN.html` and `SICE_SOC_MAIN_LINUX.html` updates from the supplied portal bridge package before enabling the service. Those files expand the existing local status mirror; they never receive or store the cloud API key. Then copy `sice_war_room_sync.py` into the Linux SICE Portal directory, for example `/opt/sice-portal/`. In the War Room web app, sign in as an administrator, open **Settings**, then generate an API key. Copy the displayed key immediately: only its hash remains in the hosted system after the display is dismissed.

Copy `sice-war-room-sync.env.example` to `/etc/sice-war-room-sync.env`, replace the webhook URL and key, and restrict it with `sudo chmod 600 /etc/sice-war-room-sync.env`. Do not place the key in HTML, JavaScript, browser local storage, or the SOC MAIN status JSON.

To test a single synchronization, run:

```bash
sudo -u YOUR_LINUX_USER env $(sudo cat /etc/sice-war-room-sync.env | xargs) \
  /usr/bin/python3 /opt/sice-portal/sice_war_room_sync.py
```

For persistent synchronization, copy `sice-war-room-sync.service` to `/etc/systemd/system/`, replace `YOUR_LINUX_USER`, then run:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now sice-war-room-sync.service
sudo systemctl status sice-war-room-sync.service
```

The bridge checks the **local file metadata** every two seconds, but sends HTTPS traffic only when the SOC MAIN mirror changes. The hosted War Room then persists the events and other open dashboard displays detect the database revision on their next sync check.

## Current source coverage

The updated SOC MAIN browser mirror includes the shared activity log, security incidents, patrols, threats, hazards, inspections, and key assets. The Linux bridge maps these to their appropriate War Room event types and preserves source severity, location, actor, and timestamp where present. Expiry records are accepted by the protected webhook contract and can be added once the local source mirror exposes an expiry collection.
