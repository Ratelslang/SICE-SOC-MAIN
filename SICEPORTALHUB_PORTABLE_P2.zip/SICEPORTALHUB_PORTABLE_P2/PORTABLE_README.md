# SICE SOC Portal — Portable Full-App Package

## Purpose

This package contains the **complete upgraded SICE SOC portal**, including the P2 Command Desk, all linked modules, PWA assets, local-service code, data folders, reports, and launchers. You may copy or share the ZIP file, extract it to another location, and run it from that extracted folder.

> **Important:** Do not open `SICE_SOC_MAIN.html` directly with `file://`. Start the local service with the supplied launcher. This is required for the PWA, local status mirror, traffic panel, and reliable inline-module workflow.

## Supported Use

| Platform | Start method | Requirement |
|---|---|---|
| **Windows** | Double-click `LAUNCH_SOC_MAIN.bat`. | Python 3 must be installed and available as `py` or `python`. |
| **Linux** | Run `chmod +x launch_sice_portal.sh` once, then `./launch_sice_portal.sh`. | Python 3 and a graphical default browser. |
| **Any platform with Python 3** | Run `python3 RUN_SICE_PORTAL.py` from the extracted folder. On Windows, use `py -3 RUN_SICE_PORTAL.py` or `python RUN_SICE_PORTAL.py`. | Python 3 standard library only; no additional packages are required. |

The launcher finds the folder it is run from, starts `sice_server.py` on port `8743`, and opens:

```text
http://127.0.0.1:8743/SICE_SOC_MAIN.html
```

## Share and Extract Procedure

Keep the ZIP intact while transferring it. On the recipient computer, extract the **entire** `SICEPORTALHUB_P2_COMMAND_DESK` folder to any writable location, such as Documents or Desktop. Do not move only `SICE_SOC_MAIN.html`; all module files, the service worker, icons, and data folders must remain together.

| Step | Action |
|---|---|
| 1 | Extract the ZIP completely. Do not open it from inside the archive viewer. |
| 2 | Keep all extracted files and folders together. |
| 3 | Start the portal using the platform launcher above. |
| 4 | Use a current desktop browser such as Chrome, Edge, Firefox, or Chromium. |
| 5 | If a PWA install was used previously, close and reopen it after the first launch so the P2 cache release can activate. |

## What Works in Another Browser or Location

The full command dashboard, existing login behavior, linked modules, local search, JOC, Activity Feed, Expiry Watchlist, PWA shell, local status mirror, and all offline-capable forms are included in the package. The package is self-contained except for the existing external services that already require network access, including the hosted MAIN SOC link, public fonts on first load, and live traffic feed retrieval.

The portal uses browser `localStorage` for much of its operational data. As a result, **each browser profile on each computer has its own local records**. Sharing this ZIP gives the recipient a working application, but it does not copy the original browser's locally stored forms, session, incidents, asset register, or other browser-held records. Use the existing export functions to transfer records deliberately when required.

The bundled local service also stores its SOC status mirror under `data/soc_main/status.json`. The included copy is part of the package, but it is not a replacement for a shared multi-user database or a live synchronization service.

## Optional PDF Report Generator

The main SOC portal and its local service use the Python 3 standard library only. The two optional monthly-report generator scripts (`generate_monthly_report.py` and `generate_monthly_report_TEMPLATE.py`) additionally require the `reportlab` package. This package is **not required** to run the portal itself. If the optional generator is needed on a new computer, install it with:

```text
python3 -m pip install reportlab
```

## Operating Notes

The current authentication and local service behavior have been deliberately preserved by the P2 release. Accordingly, the portal should be treated as an operational tool for approved devices, not as hardened shared-web access control. The existing service may listen on the local network according to the current server configuration. Do not expose the extracted folder or service port to untrusted networks.

If port `8743` is already in use, close the other portal/service instance and run the launcher again. On Windows, the launcher will explain if Python 3 is unavailable. On Linux, install Python 3 through the normal system package manager if it is missing.

## Contents Retained

| Content group | Included |
|---|---|
| `SICE_SOC_MAIN.html` with P2 Command Desk | Yes |
| All linked SOC module HTML files | Yes |
| `sice_server.py` and `RUN_SICE_PORTAL.py` | Yes |
| Windows and Linux launchers | Yes |
| PWA manifest, service worker, icons, and cache release | Yes |
| Data, reports, documentation, and supporting assets | Yes |
| Temporary development previews, tests, Git metadata, logs, and obsolete duplicate main-portal backups | No |

## Quick Recovery

If a launch problem occurs, close the browser, stop any previous local portal process, then start the supplied launcher again. The launcher writes a service log to the system temporary directory: `sice_soc_portal_server.log`.
