/* SICE SOC — Service Worker
   Bump CACHE_VERSION every time you deploy updated module files.
   Old cache entries are only replaced when the version string changes —
   otherwise the app keeps serving whatever was cached at install time,
   even if the files on disk have changed. */
const CACHE_VERSION = 'sice-soc-v18-command-desk';

const APP_SHELL = [
  './SICE_SOC_MAIN.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './OPS_.html',
  './SICE_KEY_CONTROL.html',
  './SICE_ASSET_BORROWING_MODULE.html',
  './SICE_ASSET_MANAGEMENT.html',
  './SICE_ASSET_TRACKER.html',
  './SICE_VEHICLE_INSPECTION.html',
  './SICE_HEALTH_SAFETY.html',
  './SICE_HEALTH_SAFETY_INSPECTION.html',
  './SICE_PREMISES_INSPECTION.html',
  './SICE_MOVEMENT_LOG.html',
  './SICE_CPO_OPS_DASHBOARD.html',
  './SICE_INCIDENT_DASHBOARD.html',
  './SICE_INTEL_HUB.html',
  './SICE_RECON.html',
  './SICE_FLEET_MOVEMENT.html',
  './SICE_NOTEBOOK.html',
  './SICE_CLOCK_MODULE.html',
  './SICE_CP_OPS_PLANNER.html',
  './SICE_PERSONAL.html',
  './SICE_SAFETY_INSPECTION.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => {
      // addAll fails the whole install if even one file 404s — go one by one
      // so a single missing/renamed module doesn't break offline for everything else.
      return Promise.all(
        APP_SHELL.map((url) =>
          cache.add(url).catch((err) => console.warn('[SW] skip (not found):', url, err))
        )
      );
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Cache-first, falling back to network, falling back to whatever's cached
// if the network is down. Anything successfully fetched gets cached for
// next time, so newly-visited modules become available offline too.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const networkFetch = fetch(event.request).then((response) => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => cached);

      return cached || networkFetch;
    })
  );
});
